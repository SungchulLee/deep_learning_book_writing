# Fréchet Inception Distance (FID)

The **Fréchet Inception Distance (FID)** is the standard metric for evaluating generative model quality. It measures the distance between the distribution of generated samples and real data in the feature space of a pre-trained Inception-v3 network.

## Definition

Compute Inception-v3 features (from the pool3 layer, dimension 2048) for both real images $\{x_i\}$ and generated images $\{g_j\}$. Model each set as a multivariate Gaussian and compute the Fréchet distance:

$$\text{FID} = \|\mu_r - \mu_g\|^2 + \text{tr}\!\left(\Sigma_r + \Sigma_g - 2(\Sigma_r \Sigma_g)^{1/2}\right)$$

where $(\mu_r, \Sigma_r)$ and $(\mu_g, \Sigma_g)$ are the means and covariances of real and generated feature distributions.

## Properties

**Lower is better.** FID = 0 indicates identical distributions. State-of-the-art models achieve FID 1–5 on standard benchmarks.

**Captures both quality and diversity.** The mean term measures fidelity (do generated samples look realistic?); the covariance term measures diversity (does the generator cover the full distribution?).

**Sample-size sensitive.** FID estimates are biased for small sample sizes. Standard practice uses 50,000 samples (FID-50K).

## Benchmarks

| Model | CIFAR-10 FID ↓ | ImageNet 256×256 FID ↓ |
|-------|----------------|------------------------|
| DDPM | 3.17 | — |
| ADM (Dhariwal & Nichol) | — | 10.94 |
| ADM + guidance | — | 4.59 |
| DiT-XL/2 | — | 2.27 |
| Consistency model | — | 3.55 |

## Limitations

FID assumes Gaussian feature distributions (not always valid), is sensitive to image preprocessing, and doesn't capture fine-grained perceptual quality. It should be complemented with other metrics and human evaluation.

## PyTorch Computation

```python
import torch
import numpy as np
from scipy.linalg import sqrtm


def compute_fid(
    real_features: np.ndarray, gen_features: np.ndarray
) -> float:
    """Compute FID between real and generated feature sets.

    Args:
        real_features: [N_real, 2048] Inception features.
        gen_features: [N_gen, 2048] Inception features.

    Returns:
        FID score (lower is better).
    """
    mu_r = real_features.mean(axis=0)
    mu_g = gen_features.mean(axis=0)
    sigma_r = np.cov(real_features, rowvar=False)
    sigma_g = np.cov(gen_features, rowvar=False)

    diff = mu_r - mu_g
    covmean, _ = sqrtm(sigma_r @ sigma_g, disp=False)

    if np.iscomplexobj(covmean):
        covmean = covmean.real

    fid = diff @ diff + np.trace(sigma_r + sigma_g - 2 * covmean)
    return float(fid)
```
