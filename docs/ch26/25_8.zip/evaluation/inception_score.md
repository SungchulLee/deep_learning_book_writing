# Inception Score (IS)

The **Inception Score** (Salimans et al., 2016) evaluates generated image quality using a pre-trained Inception-v3 classifier. It measures both the sharpness of individual images and the diversity of the generated set.

## Definition

$$\text{IS} = \exp\!\left(\mathbb{E}_{x \sim p_g}\!\left[D_{\text{KL}}\bigl(p(y|x) \,\|\, p(y)\bigr)\right]\right)$$

where $p(y|x)$ is the Inception classifier's softmax output for generated image $x$, and $p(y) = \mathbb{E}_{x}[p(y|x)]$ is the marginal class distribution.

## Interpretation

**High quality** → $p(y|x)$ is peaked (the classifier is confident) → large KL.

**High diversity** → $p(y)$ is uniform (many classes represented) → large KL.

Both contribute to a higher IS. Scores range from 1 (worst) to theoretically 1000 (one confident prediction per ImageNet class).

## Benchmarks

| Model | IS (CIFAR-10) ↑ | IS (ImageNet) ↑ |
|-------|-----------------|-----------------|
| Real data | 11.24 | ~300 |
| DDPM | 9.46 | — |
| BigGAN | 14.73 | 171.4 |
| StyleGAN2 | — | — |

## Limitations

IS does not compare against real data (unlike FID), ignores intra-class diversity, is biased toward ImageNet classes, and can be gamed by memorising training data. FID is generally preferred as a primary metric, with IS providing complementary information about class-conditional quality.

## PyTorch Computation

```python
import torch
import numpy as np


def inception_score(
    class_probs: np.ndarray, splits: int = 10
) -> tuple[float, float]:
    """Compute Inception Score from classifier softmax outputs.

    Args:
        class_probs: [N, num_classes] softmax probabilities.
        splits: Number of splits for mean/std estimation.

    Returns:
        (mean_IS, std_IS)
    """
    N = len(class_probs)
    split_scores = []

    for i in range(splits):
        part = class_probs[i * N // splits : (i + 1) * N // splits]
        p_y = part.mean(axis=0, keepdims=True)
        kl = part * (np.log(part + 1e-16) - np.log(p_y + 1e-16))
        kl_mean = kl.sum(axis=1).mean()
        split_scores.append(np.exp(kl_mean))

    return float(np.mean(split_scores)), float(np.std(split_scores))
```
