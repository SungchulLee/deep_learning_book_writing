# Precision and Recall for GANs

Precision and Recall metrics (Sajjadi et al., 2018; Kynkäänniemi et al., 2019) decompose GAN evaluation into two complementary aspects: **fidelity** (precision) and **coverage** (recall), providing more interpretable evaluation than FID alone.

## Motivation

FID combines quality and diversity into a single number. However, knowing *why* a GAN scores poorly requires separating these concerns:

- **High precision, low recall**: Generator produces high-quality samples but misses modes (mode collapse)
- **Low precision, high recall**: Generator covers the data distribution but individual samples are low quality
- **Both high**: Ideal generation

## Definitions

### Precision

The fraction of generated samples that fall within the support of the real data distribution:

$$\text{Precision} = \frac{|\{g \in \text{gen} : g \in \text{support}(p_{\text{data}})\}|}{|\text{gen}|}$$

**Measures**: Are generated samples realistic? (Fidelity)

### Recall

The fraction of real data samples that fall within the support of the generated distribution:

$$\text{Recall} = \frac{|\{r \in \text{real} : r \in \text{support}(p_g)\}|}{|\text{real}|}$$

**Measures**: Does the generator cover the full data distribution? (Diversity)

## Improved Precision and Recall (IPR)

Kynkäänniemi et al. (2019) proposed an improved method using k-nearest neighbors in feature space:

```python
import torch
import numpy as np
from sklearn.neighbors import NearestNeighbors

class ImprovedPrecisionRecall:
    """
    Improved Precision and Recall for GAN evaluation.
    
    Uses k-NN manifold estimation in Inception feature space.
    """
    
    def __init__(self, feature_extractor, k=3, device='cpu'):
        self.feature_extractor = feature_extractor
        self.k = k
        self.device = device
    
    def extract_features(self, images, batch_size=32):
        """Extract features using pretrained network."""
        features = []
        for i in range(0, len(images), batch_size):
            batch = images[i:i+batch_size].to(self.device)
            with torch.no_grad():
                feat = self.feature_extractor(batch)
            features.append(feat.cpu().numpy())
        return np.concatenate(features)
    
    def compute_manifold_radius(self, features):
        """Compute k-NN radius for each sample."""
        nn_model = NearestNeighbors(n_neighbors=self.k + 1, metric='euclidean')
        nn_model.fit(features)
        distances, _ = nn_model.kneighbors(features)
        # Radius = distance to k-th nearest neighbor (excluding self)
        return distances[:, -1]
    
    def compute(self, real_images, gen_images):
        """
        Compute Improved Precision and Recall.
        
        Returns:
            precision: Fraction of generated samples near real manifold
            recall: Fraction of real samples near generated manifold
        """
        # Extract features
        real_feats = self.extract_features(real_images)
        gen_feats = self.extract_features(gen_images)
        
        # Compute manifold radii
        real_radii = self.compute_manifold_radius(real_feats)
        gen_radii = self.compute_manifold_radius(gen_feats)
        
        # Precision: generated samples within real manifold
        nn_real = NearestNeighbors(n_neighbors=1, metric='euclidean')
        nn_real.fit(real_feats)
        dist_to_real, idx_real = nn_real.kneighbors(gen_feats)
        precision = np.mean(dist_to_real.flatten() <= real_radii[idx_real.flatten()])
        
        # Recall: real samples within generated manifold
        nn_gen = NearestNeighbors(n_neighbors=1, metric='euclidean')
        nn_gen.fit(gen_feats)
        dist_to_gen, idx_gen = nn_gen.kneighbors(real_feats)
        recall = np.mean(dist_to_gen.flatten() <= gen_radii[idx_gen.flatten()])
        
        return float(precision), float(recall)
```

## Density and Coverage

An alternative formulation (Naeem et al., 2020) provides smoother estimates:

```python
def density_and_coverage(real_feats, gen_feats, k=5):
    """
    Compute Density (quality) and Coverage (diversity).
    
    Density: Average number of real neighbors per generated sample
    Coverage: Fraction of real samples with a generated neighbor
    """
    nn_real = NearestNeighbors(n_neighbors=k, metric='euclidean')
    nn_real.fit(real_feats)
    
    # For each generated sample, count real neighbors within manifold
    real_radii = nn_real.kneighbors(real_feats)[0][:, -1]
    
    # Density
    dist_gen_to_real, idx = nn_real.kneighbors(gen_feats)
    in_manifold = dist_gen_to_real <= real_radii[idx]
    density = in_manifold.sum(axis=1).mean() / k
    
    # Coverage
    nn_gen = NearestNeighbors(n_neighbors=1, metric='euclidean')
    nn_gen.fit(gen_feats)
    dist_real_to_gen = nn_gen.kneighbors(real_feats)[0].flatten()
    
    gen_radii = NearestNeighbors(n_neighbors=k).fit(gen_feats).kneighbors(gen_feats)[0][:, -1]
    coverage = np.mean(dist_real_to_gen <= gen_radii[nn_gen.kneighbors(real_feats)[1].flatten()])
    
    return float(density), float(coverage)
```

## Interpreting Results

| Scenario | Precision | Recall | Interpretation |
|----------|-----------|--------|----------------|
| Ideal GAN | High | High | High quality + full diversity |
| Mode collapse | High | Low | Quality OK, missing modes |
| Blurry outputs | Low | High | Covers distribution, low quality |
| Failed training | Low | Low | Neither quality nor diversity |
| Memorization | Very high | Low | Overfitting to subset |

## Metric Comparison

| Metric | Quality | Diversity | Interpretable | Computational Cost |
|--------|---------|-----------|---------------|-------------------|
| IS | ✓ | ✓ | Low | Low |
| FID | ✓ | ✓ | Medium | Medium |
| Precision | ✓ | ✗ | High | High |
| Recall | ✗ | ✓ | High | High |

## Summary

| Aspect | Value |
|--------|-------|
| **Precision measures** | Fidelity (are samples realistic?) |
| **Recall measures** | Coverage (does generator cover data?) |
| **Method** | k-NN manifold estimation in feature space |
| **Feature space** | Inception-v3 (or domain-specific) |
| **Higher is better** | Yes (both) |
| **Recommended k** | 3–5 |
| **Recommended samples** | ≥ 5,000 |

Precision and Recall provide essential diagnostic information beyond what FID alone can offer, helping practitioners identify and address specific failure modes in GAN training.
