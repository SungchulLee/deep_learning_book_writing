# Inception Score (IS)

The Inception Score (Salimans et al., 2016) was one of the first quantitative metrics for evaluating GAN-generated images, measuring both quality and diversity using a pretrained Inception network.

## Mathematical Formulation

The Inception Score is defined as:

$$\text{IS} = \exp\left(\mathbb{E}_{x \sim p_g} \left[ D_{KL}(p(y|x) \| p(y)) \right]\right)$$

where:
- $p(y|x)$: Conditional class distribution from Inception-v3 for generated image $x$
- $p(y) = \mathbb{E}_x[p(y|x)]$: Marginal class distribution over all generated images
- $D_{KL}$: Kullback-Leibler divergence

### What IS Measures

| Component | Measures | Good Score Requires |
|-----------|----------|---------------------|
| $p(y|x)$ sharp (low entropy) | **Quality** | Each image clearly belongs to one class |
| $p(y)$ uniform (high entropy) | **Diversity** | Images span many different classes |

The KL divergence is large when these two conditions are met: individual images are recognizable **and** the collection is diverse.

### Score Range

- **Minimum**: IS ≈ 1 (random noise, uniform $p(y|x)$)
- **Maximum**: IS = number of classes (perfect quality and diversity)
- **ImageNet GANs**: IS ranges from ~10 (early GANs) to ~300+ (BigGAN)

## Implementation

```python
import torch
import torch.nn as nn
import torch.nn.functional as F
import numpy as np
from torchvision import models, transforms
from scipy.stats import entropy

class InceptionScoreCalculator:
    """
    Calculate Inception Score for generated images.
    
    Uses pretrained Inception-v3 to evaluate image quality and diversity.
    """
    
    def __init__(self, device='cpu', resize=True):
        self.device = device
        self.resize = resize
        
        # Load pretrained Inception-v3
        self.inception = models.inception_v3(pretrained=True, transform_input=False)
        self.inception.eval()
        self.inception.to(device)
        
        # Preprocessing
        self.transform = transforms.Compose([
            transforms.Resize(299) if resize else transforms.Lambda(lambda x: x),
            transforms.Normalize(mean=[0.485, 0.456, 0.406],
                               std=[0.229, 0.224, 0.225])
        ])
    
    def get_predictions(self, images, batch_size=32):
        """Get Inception-v3 softmax predictions for images."""
        all_preds = []
        
        for i in range(0, len(images), batch_size):
            batch = images[i:i+batch_size].to(self.device)
            
            # Resize if needed
            if self.resize and batch.size(-1) != 299:
                batch = F.interpolate(batch, size=299, mode='bilinear', 
                                     align_corners=False)
            
            # Handle grayscale
            if batch.size(1) == 1:
                batch = batch.repeat(1, 3, 1, 1)
            
            with torch.no_grad():
                preds = F.softmax(self.inception(batch), dim=1)
            
            all_preds.append(preds.cpu().numpy())
        
        return np.concatenate(all_preds, axis=0)
    
    def compute_score(self, images, splits=10):
        """
        Compute Inception Score.
        
        Args:
            images: Tensor of generated images (N, C, H, W) in [0, 1]
            splits: Number of splits for mean/std computation
        
        Returns:
            mean_is: Mean Inception Score
            std_is: Standard deviation across splits
        """
        preds = self.get_predictions(images)
        
        # Compute IS over splits
        scores = []
        split_size = len(preds) // splits
        
        for i in range(splits):
            part = preds[i * split_size:(i + 1) * split_size]
            
            # p(y|x) for each image
            py_given_x = part
            
            # p(y) = marginal
            py = np.mean(part, axis=0, keepdims=True)
            
            # KL(p(y|x) || p(y)) for each image
            kl_divs = np.sum(py_given_x * (np.log(py_given_x + 1e-10) 
                             - np.log(py + 1e-10)), axis=1)
            
            # IS = exp(mean KL)
            scores.append(np.exp(np.mean(kl_divs)))
        
        return float(np.mean(scores)), float(np.std(scores))
```

## Usage

```python
# Calculate IS for a trained generator
calculator = InceptionScoreCalculator(device='cuda')

# Generate samples
z = torch.randn(5000, latent_dim, device='cuda')
with torch.no_grad():
    generated = (generator(z) + 1) / 2  # Denormalize to [0, 1]

mean_is, std_is = calculator.compute_score(generated)
print(f"Inception Score: {mean_is:.2f} ± {std_is:.2f}")
```

## Limitations

| Limitation | Description |
|-----------|-------------|
| **No real data comparison** | Only evaluates generated images, not similarity to training data |
| **Inception bias** | Biased toward ImageNet-like features |
| **Mode dropping** | Can miss dropped modes if remaining modes are high quality |
| **Not suitable for non-image data** | Requires image classification network |
| **Insensitive to intra-class diversity** | Only measures inter-class diversity |

These limitations motivated the development of [FID](fid.md) and [Precision-Recall](precision_recall.md) metrics.

## Summary

| Aspect | Value |
|--------|-------|
| **Measures** | Quality × Diversity |
| **Network** | Pretrained Inception-v3 |
| **Higher is better** | Yes |
| **Compares to real data** | No |
| **Recommended samples** | ≥ 5,000 |
| **Splits** | 10 (standard) |
