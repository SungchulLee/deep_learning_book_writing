# Fréchet Inception Distance (FID)

The Fréchet Inception Distance (Heusel et al., 2017) is the most widely used metric for evaluating GANs, measuring the distance between the distributions of real and generated images in Inception feature space.

## Mathematical Formulation

FID models the Inception-v3 feature distributions of real and generated images as multivariate Gaussians and computes their Fréchet distance:

$$\text{FID} = \|\mu_r - \mu_g\|^2 + \text{Tr}\left(\Sigma_r + \Sigma_g - 2(\Sigma_r \Sigma_g)^{1/2}\right)$$

where:
- $(\mu_r, \Sigma_r)$: Mean and covariance of real image features
- $(\mu_g, \Sigma_g)$: Mean and covariance of generated image features
- $\text{Tr}$: Matrix trace

### Properties

- **FID = 0**: Identical distributions (perfect generation)
- **Lower is better**: Closer distributions → better quality
- **Sensitive to**: Both quality (mean difference) and diversity (covariance difference)
- **Uses real data**: Unlike IS, directly compares to the training distribution

## Implementation

```python
import torch
import numpy as np
from scipy import linalg
from torchvision import models
import torch.nn.functional as F

class FIDCalculator:
    """
    Calculate Fréchet Inception Distance between real and generated images.
    """
    
    def __init__(self, device='cpu'):
        self.device = device
        
        # Load Inception-v3 and extract features before final classification
        inception = models.inception_v3(pretrained=True, transform_input=False)
        
        # Remove final classification layer
        self.feature_extractor = nn.Sequential(*list(inception.children())[:-1])
        self.feature_extractor.eval()
        self.feature_extractor.to(device)
    
    def extract_features(self, images, batch_size=32):
        """Extract 2048-d Inception features."""
        features = []
        
        for i in range(0, len(images), batch_size):
            batch = images[i:i+batch_size].to(self.device)
            
            # Resize to 299×299
            if batch.size(-1) != 299:
                batch = F.interpolate(batch, size=299, mode='bilinear',
                                     align_corners=False)
            
            # Handle grayscale
            if batch.size(1) == 1:
                batch = batch.repeat(1, 3, 1, 1)
            
            with torch.no_grad():
                feat = self.feature_extractor(batch)
                feat = F.adaptive_avg_pool2d(feat, (1, 1)).squeeze(-1).squeeze(-1)
            
            features.append(feat.cpu().numpy())
        
        return np.concatenate(features, axis=0)
    
    def compute_statistics(self, features):
        """Compute mean and covariance of features."""
        mu = np.mean(features, axis=0)
        sigma = np.cov(features, rowvar=False)
        return mu, sigma
    
    def frechet_distance(self, mu1, sigma1, mu2, sigma2):
        """
        Compute Fréchet distance between two multivariate Gaussians.
        
        FID = ||mu1 - mu2||² + Tr(sigma1 + sigma2 - 2*sqrt(sigma1 @ sigma2))
        """
        diff = mu1 - mu2
        
        # Product of covariances
        covmean, _ = linalg.sqrtm(sigma1 @ sigma2, disp=False)
        
        # Handle numerical instability
        if np.iscomplexobj(covmean):
            covmean = covmean.real
        
        fid = diff @ diff + np.trace(sigma1 + sigma2 - 2 * covmean)
        return float(fid)
    
    def compute_fid(self, real_images, generated_images):
        """
        Compute FID between real and generated image sets.
        
        Args:
            real_images: Tensor (N, C, H, W) in [0, 1]
            generated_images: Tensor (M, C, H, W) in [0, 1]
        
        Returns:
            FID score (lower is better)
        """
        # Extract features
        real_features = self.extract_features(real_images)
        gen_features = self.extract_features(generated_images)
        
        # Compute statistics
        mu_r, sigma_r = self.compute_statistics(real_features)
        mu_g, sigma_g = self.compute_statistics(gen_features)
        
        # Compute FID
        return self.frechet_distance(mu_r, sigma_r, mu_g, sigma_g)
```

## Usage

```python
fid_calc = FIDCalculator(device='cuda')

# Real images from dataloader
real_images = torch.cat([batch for batch, _ in dataloader])
real_images = (real_images + 1) / 2  # Denormalize

# Generated images
z = torch.randn(len(real_images), latent_dim, device='cuda')
with torch.no_grad():
    gen_images = (generator(z) + 1) / 2

fid_score = fid_calc.compute_fid(real_images, gen_images)
print(f"FID: {fid_score:.2f}")
```

## Reference FID Scores

| Model | Dataset | FID |
|-------|---------|-----|
| DCGAN | CIFAR-10 | ~37 |
| WGAN-GP | CIFAR-10 | ~29 |
| SN-GAN | CIFAR-10 | ~21 |
| BigGAN | ImageNet 128×128 | ~8.7 |
| StyleGAN2 | FFHQ 1024×1024 | ~2.84 |
| Diffusion (DDPM) | CIFAR-10 | ~3.17 |

## Advantages over Inception Score

| Aspect | IS | FID |
|--------|-----|-----|
| Compares to real data | No | Yes |
| Detects mode dropping | Partial | Yes |
| Detects mode collapse | Partial | Yes |
| Measures quality | Yes | Yes |
| Measures diversity | Yes | Yes |
| Robustness | Lower | Higher |

## Limitations

- **Sample size sensitivity**: Needs ≥ 10,000 samples for reliable estimates
- **Gaussian assumption**: Assumes feature distributions are Gaussian
- **Inception features**: May miss domain-specific quality aspects
- **Computational cost**: Requires forward pass through Inception for all images

## Connection to TTUR

FID was introduced alongside the Two-Timescale Update Rule (TTUR). The authors showed that TTUR-trained GANs achieve better FID scores due to more stable convergence to the Nash equilibrium.

## Summary

| Aspect | Value |
|--------|-------|
| **Measures** | Distribution distance in feature space |
| **Network** | Pretrained Inception-v3 (pool3 layer) |
| **Lower is better** | Yes |
| **Compares to real data** | Yes |
| **Recommended samples** | ≥ 10,000 (both real and generated) |
| **Feature dimension** | 2,048 |
